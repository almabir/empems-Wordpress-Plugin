<?php

/**
 * Fired during plugin activation
 *
 * @link       www.etutorpro.com/admin
 * @since      1.0.0
 *
 * @package    Empems
 * @subpackage Empems/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Empems
 * @subpackage Empems/includes
 * @author     Md Omar Faruque <abir43tee@gmail.com>
 */
class Empems_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		global $table_prefix, $wpdb;

		#########################Tables Name #################
		######################################################
		$tblname = 'etp_employee';
		$wp_track_table_emp = $table_prefix . $tblname;

		$tblname = 'etp_department';
		$wp_track_table_dept = $table_prefix . $tblname;

		$tblname = 'etp_posts';
		$wp_track_table_post = $table_prefix . $tblname;
	
		
		##############Creation of Department Table ########################
		###################################################################
		// $tblname = 'etp_department';
		// $wp_track_table_dept = $table_prefix . $tblname;
	
		#Check to see if the table exists already, if not, then create it
		if($wpdb->get_var( "show tables like '$wp_track_table_dept'" ) != $wp_track_table_dept) 
		{
			//Creating Table for the CPT
			$sql = "CREATE TABLE $wp_track_table_dept (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`d_name` varchar(100) NOT NULL UNIQUE,				
				`created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY (`id`)
			  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
		
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
			//Inserting Demo Data to the Table
			$insert = "INSERT INTO $wp_track_table_dept ( `id`, `d_name`, `created_at`) VALUES ('', 'Engeneering Department', '')";
			$wpdb->query( $insert );
		}

		##############Creation of Posts Table ########################
		###################################################################
		// $tblname = 'etp_posts';
		// $wp_track_table_post = $table_prefix . $tblname;
	
		#Check to see if the table exists already, if not, then create it
		if($wpdb->get_var( "show tables like '$wp_track_table_post'" ) != $wp_track_table_post) 
		{
			//Creating Table for the CPT
			$sql = "CREATE TABLE $wp_track_table_post (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`p_name` varchar(100) NOT NULL UNIQUE,				
				`created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY (`id`)
			  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
		
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
			//Inserting Demo Data to the Table
			$insert = "INSERT INTO $wp_track_table_post ( `id`, `p_name`, `created_at`) VALUES ('', 'Software Developer', '')";
			$wpdb->query( $insert );
		}

		###############################Employee Table###################
		################################################################

		#Check to see if the table exists already, if not, then create it
		if($wpdb->get_var( "show tables like '$wp_track_table_emp'" ) != $wp_track_table_emp) 
		{
			//Creating Table for the CPT
			$sql = "CREATE TABLE $wp_track_table_emp (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`f_name` varchar(100) NOT NULL,
				`l_name` varchar(100) NOT NULL,
				`email` varchar(100) NOT NULL,
				`dob` date NOT NULL,
				`join_date` date NOT NULL,
				`mobile` varchar(15) NOT NULL,
				`d_name` int(11) NOT NULL,
				`p_name` int(11) NOT NULL,
				`salary` decimal(10,2) NOT NULL,
				`city` varchar(100) NOT NULL,
				`country` varchar(100) NOT NULL,
				`zip` int(10) NOT NULL,
				`profile_image` text NOT NULL,
				`status` varchar(1),
				`createdBy` int(10) NOT NULL,
				`created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY (`id`),
				FOREIGN KEY (d_name) REFERENCES $wp_track_table_dept(id) ON DELETE CASCADE,
				FOREIGN KEY (p_name) REFERENCES $wp_track_table_post(id) ON DELETE CASCADE
			  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
		
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );			
		}


		//Page Creation during activation
		if ( null === $wpdb->get_row( "SELECT post_name FROM {$wpdb->prefix}posts WHERE post_name = 'all-employees-list'", 'ARRAY_A' ) ) {
     
			$current_user = wp_get_current_user();
			
			// create post object
			$page = array(
			  'post_title'  => __( 'All Employees list' ),
			  'post_name' => 'all-employees-list',
			  'post_status' => 'publish',
			  'post_author' => $current_user->ID,
			  'post_type'   => 'page',
			  'post_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem ullam iste qui debitis earum aut totam laborum autem, eaque aliquam, porro non pariatur sed molestias quibusdam saepe dolor sapiente voluptatum?',
			);
			
			// insert the post into the database
			wp_insert_post( $page );
		}
	}

}
