<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.etutorpro.com/admin
 * @since      1.0.0
 *
 * @package    Empems
 * @subpackage Empems/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Empems
 * @subpackage Empems/includes
 * @author     Md Omar Faruque <abir43tee@gmail.com>
 */
class Empems_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		global $table_prefix, $wpdb;
		$tblname = 'etp_employee';
		$wp_track_table = $table_prefix . "$tblname ";

		//Delete Page when Plugin Deactivated
		$getData = $wpdb->get_row( "SELECT ID FROM {$wpdb->prefix}posts WHERE post_name = 'all-employees-list'");
		$pageId = $getData->ID;
		if($pageId > 0){
			wp_delete_post($pageId, true);
		}
	}

}
