<div class="container" style="max-width:1400px; margin:auto;">
    <div class="row justify-content-center">
        <div class="col-12">
            <h2 style="text-align:center; margin-bottom:10px;">Employee List</h2>
            <table class="table table-hover" id="emp-datatable">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Profile</th>
                    <th scope="col">Name</th>
                    <th scope="col">Dept.</th>
                    <th scope="col">Post</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Salary</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Profile</th>
                    <th scope="col">Name</th>
                    <th scope="col">Dept.</th>
                    <th scope="col">Post</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Salary</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </tfoot>
            <tbody>
            <?php
                global $table_prefix, $wpdb;
                    
                    $tblname = 'etp_employee';
                    $wp_track_table_emp = $table_prefix . $tblname;

                    $tblname = 'etp_department';
                    $wp_track_table_dept = $table_prefix . $tblname;

                    $tblname = 'etp_posts';
                    $wp_track_table_post = $table_prefix . $tblname;

                $result = $wpdb->get_results ( "SELECT e.*, d.d_name, p.p_name FROM $wp_track_table_emp e LEFT JOIN $wp_track_table_dept d ON e.d_name = d.id LEFT JOIN $wp_track_table_post p ON e.p_name = p.id" );
                foreach ( $result as $index => $print ) {
            ?>
                <tr>
                    <th scope="row"><?php echo ++$index; ?></th>
                    <td><img src="<?php echo $print->profile_image; ?>" alt="" width="150"></td>
                    <td><?php echo $print->f_name . " " . $print->l_name; ?></td>
                    <td><?php echo $print->d_name; ?></td>
                    <td><?php echo $print->p_name; ?></td>
                    <td><?php echo $print->email; ?></td>
                    <td><?php echo $print->mobile; ?></td>
                    <td><?php echo $print->salary; ?></td>
                    <td><?php if($print->status==1){echo '<span class="badge bg-success">Active</span>';} else {echo '<span class="badge bg-danger">Inactive</span>';} ?>  </td>
                    <td> 
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <button type="button" class="btn btn-link" id="emp-edit" data-id="<?php echo $print->id; ?>">Details</button>                        
                        </div>
                    </td>
                </tr>  
            <?php
                }
            ?>     
            </tbody>
        </table>
        </div>
    </div>
</div>