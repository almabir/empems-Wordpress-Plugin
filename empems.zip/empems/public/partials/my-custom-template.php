<?php
get_header();

do_shortcode("[ETP_EMP-shortcode]");

get_footer();
?>