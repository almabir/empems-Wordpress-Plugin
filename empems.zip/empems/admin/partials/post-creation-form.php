<?php
    wp_enqueue_media();
    if(!isset($_REQUEST['post_id'])){
?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Departmental Post Creation Form</h2> 
            </div>
            <div class="card-body">
            <form class="row g-3" id="etp-post-submit-form" action="javascript:void(0)" method="POST">
                <div class="col-md-12">
                    <label for="p_name" class="form-label">Departmental Post Name</label>
                    <input name="p_name" type="text" class="form-control" id="p_name" placeholder="Departmental Post Name" required>
                </div>
                <div class="col-12">
                    <button class="btn btn-primary float-end" type="submit">Submit for Creation</button>
                </div>
            </form>
            </div>
            <div class="card-footer">
                <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
            </div>

        </div>
        </div>
<?php

    }else{
        
        global $table_prefix, $wpdb;
                $tblname = 'etp_posts';
                $wp_track_table_post = $table_prefix . $tblname;
                $p_id = $_REQUEST['post_id'];
                $result = $wpdb->get_row ( "SELECT * FROM $wp_track_table_post WHERE id = $p_id" );
       ?> 

        <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Departmental Post Editing Form</h2> 
            </div>
            <div class="card-body">
            <form class="row g-3" id="etp-post-update-form" action="javascript:void(0)" method="POST">
                <div class="col-md-12">
                    <label for="p_name" class="form-label">Departmental Post Name</label>
                    <input value="<?php echo $result->p_name; ?>" name="p_name" type="text" class="form-control" id="p_name" placeholder="Departmental Post Name" required>
                    <input type="hidden" name="row_id" value="<?php echo $p_id; ?>">

                </div>
                <div class="col-12">
                    <button class="btn btn-primary float-end" type="submit">Submit for Update</button>
                </div>
            </form>
            </div>
            <div class="card-footer">
                <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
            </div>

        </div>
        </div>
<?php
    }
?>  
