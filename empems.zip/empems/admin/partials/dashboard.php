<div class="container">
    <div class="row">
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">All Employee Info</div>
            <div class="card-body">
                <h5 class="card-title">All Employee Info</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">All Department Info</div>
            <div class="card-body">
                <h5 class="card-title">All Department Info</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">All Posts Info</div>
            <div class="card-body">
                <h5 class="card-title">All Posts Info</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
        </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">Plugin Shortcode</div>
            <div class="card-body">
                <h5 class="card-title">Plugin Shortcode</h5>
                <p class="card-text">To show all Employee info use the shortcode: <b>[ETP_EMP-shortcode]</b></p>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">Developer Info</div>
            <div class="card-body">
                <h5 class="card-title">Developer Info</h5>
                <p class="card-text"><b>Name: </b> abir43tee@gmail.com<br>
                                    <b>Website:</b> <a href="http://etutorpro.com"> http://etutorpro.com </a><br>
                                    <b>Skype: </b> abir43tee</p>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card text-dark bg-info mb-3">
            <div class="card-header">To Donate</div>
            <div class="card-body">
                <h5 class="card-title">To Donate</h5>
                <p class="card-text">If you want to donate, please send any amount to Skrill account: abir43tee@gmail.com</p>
            </div>
        </div>
        </div>
    </div>
</div>