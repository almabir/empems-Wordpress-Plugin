<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>All Departmental Post Available</h2>
        </div>
        <div class="card-body">
        <table class="table table-hover" id="emp-datatable">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Departmental Post Name</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tfoot>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Departmental Post Name</th>
                <th scope="col">Action</th>
                </tr>
            </tfoot>
            <tbody>
            <?php
                global $table_prefix, $wpdb;
                    $tblname = 'etp_posts';
                    $wp_track_table_post = $table_prefix . $tblname;

                $result = $wpdb->get_results ( "SELECT * FROM $wp_track_table_post" );
                foreach ( $result as $index => $print ) {
            ?>
                <tr>
                <th scope="row"><?php echo ++$index; ?></th>
                <td><?php echo $print->p_name; ?></td>
                <td> 
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary" id="edit-etp-post" data-id="<?php echo $print->id; ?>">Edit</button>
                        <button type="button" class="btn btn-danger" id="" data-id="<?php echo $print->id; ?>">Delete</button>                            
                    </div>
                </td>
                </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
        </div>
        <div class="card-footer">
            <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
        </div>
    
    </div>
</div>