<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>All Departments Available</h2>
        </div>
        <div class="card-body">
        <table class="table table-hover" id="emp-datatable">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Department Name</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tfoot>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Department Name</th>
                <th scope="col">Action</th>
                </tr>
            </tfoot>
            <tbody>
            <?php
                global $table_prefix, $wpdb;
                    $tblname = 'etp_department';
                    $wp_track_table_dept = $table_prefix . $tblname;

                $result = $wpdb->get_results ( "SELECT * FROM $wp_track_table_dept" );
                foreach ( $result as $index => $print ) {
            ?>
                <tr>
                <th scope="row"><?php echo ++$index; ?></th>
                <td><?php echo $print->d_name; ?></td>
                <td> 
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary" id="edit-etp-dept" data-id="<?php echo $print->id; ?>">Edit</button>
                        <button type="button" class="btn btn-danger" id="delete-etp-dept" data-id="<?php echo $print->id; ?>">Delete</button>                            
                    </div>
                </td>
                </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
        </div>
        <div class="card-footer">
            <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
        </div>
    
    </div>
</div>