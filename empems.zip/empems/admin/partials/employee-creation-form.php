<?php
    wp_enqueue_media();
    if(!isset($_REQUEST['emp_id'])){
?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Employee Creation Form</h2> 
            </div>
            <div class="card-body">
            <form class="row g-3" id="etp-emp-submit-form" action="javascript:void(0)" method="POST">
                <div class="col-md-4">
                    <label for="f_name" class="form-label">First Name</label>
                    <input name="f_name" type="text" class="form-control" id="f_name" placeholder="First Name" required>
                </div>
                <div class="col-md-4">
                    <label for="l_name" class="form-label">Last name</label>
                    <input name="l_name" type="text" class="form-control" id="l_name" placeholder="Last Name" required>
                </div>
                <div class="col-md-4">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-group">
                    <span class="input-group-text" id="inputGroupPrepend2">@</span>
                    <input name="email" type="email" placeholder="Email Address" class="form-control" id="email"  aria-describedby="inputGroupPrepend2" required>
                    </div>
                </div>

                <div class="col-md-4">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input name="dob" type="date" class="form-control" id="dob" required>
                </div>
                <div class="col-md-4">
                    <label for="join_date" class="form-label">Date of Join</label>
                    <input name="join_date" type="date" class="form-control" id="join_date"  required>
                </div>
                <div class="col-md-4">
                    <label for="mobile" class="form-label">Mobile No</label>
                    <div class="input-group">
                    <span class="input-group-text" id="mobileNo">#</span>
                    <input name="mobile" type="text" class="form-control" id="mobile"  aria-describedby="mobileNo" placeholder="Mobile Number" required>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <label for="department" class="form-label">Name of Department</label>
                    <select name="department" class="form-select" id="department" required>
                    <option selected disabled value="">Choose Department</option>
                    <?php
                    global $table_prefix, $wpdb;

                        $tblname = 'etp_department';
                        $wp_track_table_dept = $table_prefix . $tblname;

                    $result = $wpdb->get_results ( "SELECT * FROM $wp_track_table_dept" );
                    foreach ( $result as $index => $print ) {
                    ?>
                    <option value="<?php echo $print->id; ?>"><?php echo $print->d_name; ?></option>
                    <?php } ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="post_name" class="form-label">Post Holding</label>
                    <select name="post_name" class="form-select" id="post_name" required>
                    <option selected disabled value="">Choose Post</option>
                    <?php
                    global $table_prefix, $wpdb;

                    $tblname = 'etp_posts';
                    $wp_track_table_post = $table_prefix . $tblname;

                    $result = $wpdb->get_results ( "SELECT * FROM $wp_track_table_post" );
                    foreach ( $result as $index => $print ) {
                    ?>
                    <option value="<?php echo $print->id; ?>"><?php echo $print->p_name; ?></option>
                    <?php } ?>
                    </select>
                    
                </div>
                
                <div class="col-md-4">
                    <label for="salary" class="form-label">Salary Amount</label>
                    <div class="input-group">
                    <span class="input-group-text" id="salary1">$</span>
                    <input name="salary" placeholder="Salary to Pay" type="text" class="form-control" id="salary"  aria-describedby="salary1" required>
                    </div>
                </div>

                <div class="col-md-4">
                    <label for="city" class="form-label">City</label>
                    <input name="city" placeholder="City Name" type="text" class="form-control" id="city" required>
                </div>
                <div class="col-md-4">
                    <label for="country" class="form-label">Country</label>
                    <input name="country" placeholder="Country Name" type="text" class="form-control" id="country" required>
                </div>
                <!-- <div class="col-md-3">
                    <label for="validationDefault04" class="form-label">State</label>
                    <select class="form-select" id="validationDefault04" required>
                    <option selected disabled value="">Choose...</option>
                    <option>...</option>
                    </select>
                </div> -->
                <div class="col-md-4">
                    <label for="zip" class="form-label">Zip</label>
                    <input name="zip" placeholder="Zip Code" type="number" class="form-control" id="zip" required>
                </div>
                <!-- <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                    <label class="form-check-label" for="invalidCheck2">
                        Agree to terms and conditions
                    </label>
                    </div>
                </div> -->
                <div class="col-md-4">
                    <label for="ajax_image_admin" class="form-label">Profile Picture</label>
                    <input name="image" type="button" value="Upload Image" class="form-control" id="ajax_image_emp" required>
                </div>
                <div class="col-md-8">
                    <img class="pt-2" src="" alt="" id="emp_image_file">
                    <input type="hidden" name="emp_image_selection" id="emp_image_selection">
                </div>
                <hr>
            <div class="col-12">
                    <div class="form-check">
                    <input name="status" class="form-check-input" type="checkbox" value="1" id="status">
                    <label class="form-check-label" for="status">
                        Checked for Activating This Employee
                    </label>
                    </div>
                </div>
                <div class="col-12">
                    <button class="btn btn-primary float-end" type="submit">Submit for Creation</button>
                </div>
            </form>
            </div>
            <div class="card-footer">
                <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
            </div>

        </div>
        </div>
<?php

    }else{
        
        global $table_prefix, $wpdb;
                    
                    $tblname = 'etp_employee';
                    $wp_track_table_emp = $table_prefix . $tblname;

                    $tblname = 'etp_department';
                    $wp_track_table_dept = $table_prefix . $tblname;

                    $tblname = 'etp_posts';
                    $wp_track_table_post = $table_prefix . $tblname;
                $emp_id = $_REQUEST['emp_id'];
                $result = $wpdb->get_row ( "SELECT * FROM $wp_track_table_emp WHERE id = $emp_id" );
       ?> 

        <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Employee Edit Form</h2> 
            </div>
            <div class="card-body">
            <form class="row g-3" id="etp-emp-update-form" action="javascript:void(0)" method="POST">
                <div class="col-md-4">
                    <label for="f_name" class="form-label">First Name</label>
                    <input value="<?php echo $result->f_name; ?>" name="f_name" type="text" class="form-control" id="f_name" placeholder="First Name" required>
                </div>
                <div class="col-md-4">
                    <label for="l_name" class="form-label">Last name</label>
                    <input value="<?php echo $result->l_name; ?>" name="l_name" type="text" class="form-control" id="l_name" placeholder="Last Name" required>
                </div>
                <div class="col-md-4">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-group">
                    <span class="input-group-text" id="inputGroupPrepend2">@</span>
                    <input value="<?php echo $result->email; ?>" name="email" type="email" placeholder="Email Address" class="form-control" id="email"  aria-describedby="inputGroupPrepend2" required>
                    </div>
                </div>

                <div class="col-md-4">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input value="<?php echo $result->dob; ?>" name="dob" type="date" class="form-control" id="dob" required>
                </div>
                <div class="col-md-4">
                    <label for="join_date" class="form-label">Date of Join</label>
                    <input value="<?php echo $result->join_date; ?>" name="join_date" type="date" class="form-control" id="join_date"  required>
                </div>
                <div class="col-md-4">
                    <label for="mobile" class="form-label">Mobile No</label>
                    <div class="input-group">
                    <span class="input-group-text" id="mobileNo">#</span>
                    <input value="<?php echo $result->mobile; ?>" name="mobile" type="text" class="form-control" id="mobile"  aria-describedby="mobileNo" placeholder="Mobile Number" required>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <label for="department" class="form-label">Name of Department</label>
                    <select name="department" class="form-select" id="department" required>
                    <option selected disabled value="">Choose Department</option>
                    <?php
                    global $table_prefix, $wpdb;

                        $tblname = 'etp_department';
                        $wp_track_table_dept = $table_prefix . $tblname;

                    $results = $wpdb->get_results ( "SELECT * FROM $wp_track_table_dept" );
                    foreach ( $results as $index => $print ) {
                    ?>
                    <option value="<?php echo $print->id; ?>" <?php if($result->d_name == $print->id){echo "selected";} ?> ><?php echo $print->d_name; ?></option>
                    <?php } ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="post_name" class="form-label">Post Holding</label>
                    <select name="post_name" class="form-select" id="post_name" required>
                    <option selected disabled value="">Choose Post</option>
                    <?php
                    global $table_prefix, $wpdb;

                    $tblname = 'etp_posts';
                    $wp_track_table_post = $table_prefix . $tblname;

                    $results = $wpdb->get_results ( "SELECT * FROM $wp_track_table_post" );
                    foreach ( $results as $index => $print ) {
                    ?>
                    <option value="<?php echo $print->id; ?>" <?php if($result->p_name == $print->id){echo "selected";} ?>><?php echo $print->p_name; ?></option>
                    <?php } ?>
                    </select>
                    
                </div>
                
                <div class="col-md-4">
                    <label for="salary" class="form-label">Salary Amount</label>
                    <div class="input-group">
                    <span class="input-group-text" id="salary1">$</span>
                    <input value="<?php echo $result->salary; ?>" name="salary" placeholder="Salary to Pay" type="text" class="form-control" id="salary"  aria-describedby="salary1" required>
                    </div>
                </div>

                <div class="col-md-4">
                    <label for="city" class="form-label">City</label>
                    <input value="<?php echo $result->city; ?>" name="city" placeholder="City Name" type="text" class="form-control" id="city" required>
                </div>
                <div class="col-md-4">
                    <label for="country" class="form-label">Country</label>
                    <input value="<?php echo $result->country; ?>" name="country" placeholder="Country Name" type="text" class="form-control" id="country" required>
                </div>
                <!-- <div class="col-md-3">
                    <label for="validationDefault04" class="form-label">State</label>
                    <select class="form-select" id="validationDefault04" required>
                    <option selected disabled value="">Choose...</option>
                    <option>...</option>
                    </select>
                </div> -->
                <div class="col-md-4">
                    <label for="zip" class="form-label">Zip</label>
                    <input value="<?php echo $result->zip; ?>" name="zip" placeholder="Zip Code" type="number" class="form-control" id="zip" required>
                </div>
                <!-- <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                    <label class="form-check-label" for="invalidCheck2">
                        Agree to terms and conditions
                    </label>
                    </div>
                </div> -->
                <div class="col-md-4">
                    <label for="ajax_image_admin" class="form-label">Profile Picture</label>
                    <input  name="image" type="button" value="Upload Image" class="form-control" id="ajax_image_emp" required>
                </div>
                <div class="col-md-8">
                    <img width="150" src="<?php echo $result->profile_image; ?>" class="pt-2" src="" alt="" id="emp_image_file">
                    <input value="<?php echo $result->profile_image; ?>" type="hidden" name="emp_image_selection" id="emp_image_selection">
                </div>
                <hr>
            <div class="col-12">
                    <div class="form-check">
                    <input <?php if($result->status) echo "checked"; ?> name="status" class="form-check-input" type="checkbox" value="1" id="status">
                    <label class="form-check-label" for="status">
                        Checked for Activating This Employee
                    </label>
                    </div>
                </div>
                <input type="hidden" value="<?php echo $emp_id?>" name="row_id">
                <div class="col-12">
                    <button class="btn btn-primary float-end" type="submit">Update Employee</button>
                </div>
            </form>
            </div>
            <div class="card-footer">
                <p class="float-end">A product of <a href="http://etutorpro.com/">eTutorPro </a></p>
            </div>

        </div>
        </div>
<?php
    }
?>  
