<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.etutorpro.com/admin
 * @since      1.0.0
 *
 * @package    Empems
 * @subpackage Empems/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Empems
 * @subpackage Empems/admin
 * @author     Md Omar Faruque <abir43tee@gmail.com>
 */
class Empems_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Empems_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Empems_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$valid_pages = array("ETP_EMP_dashboard", "ept_all_employee", "ept_add_employee", "etp_all_department", "etp_add_department", "etp_all_dept_post", "etp_add_dept_post");

		$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : "";

		if( in_array($page, $valid_pages) ){
		wp_enqueue_style( $this->plugin_name."bootstrap", plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name."dataTables_bootstrap5", plugin_dir_url( __FILE__ ) . 'css/dataTables.bootstrap5.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name."dataTables_bootstrap", plugin_dir_url( __FILE__ ) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name."sweetalert", plugin_dir_url( __FILE__ ) . 'css/sweetalert.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/empems-admin.css', array(), $this->version, 'all' );
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Empems_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Empems_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		$valid_pages = array("ETP_EMP_dashboard", "ept_all_employee", "ept_add_employee", "etp_all_department", "etp_add_department", "etp_all_dept_post", "etp_add_dept_post");

		$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : "";

		if( in_array($page, $valid_pages) ){

			wp_enqueue_script( $this->plugin_name."boostrap", plugin_dir_url( __FILE__ ) . 'js/bootstrap.bundle.min.js', array( 'jquery' ), $this->version, false );

			wp_enqueue_script( $this->plugin_name."dataTables", plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
			wp_enqueue_script( $this->plugin_name."dataTablesB5", plugin_dir_url( __FILE__ ) . 'js/dataTables.bootstrap5.min.js', array( 'jquery' ), $this->version, false );
	
			wp_enqueue_script( $this->plugin_name."sweetalert", plugin_dir_url( __FILE__ ) . 'js/sweetalert.min.js', array( 'jquery' ), $this->version, false );
	
			wp_enqueue_script( $this->plugin_name."validation", plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );

			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/empems-admin.js', array( 'jquery' ), $this->version, false );
			//Localizing for ajax Request
			wp_localize_script( $this->plugin_name, "etp_EMS_admin_ajax", array( 
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				// 'name' => 'Omar Faruque',
				// 'sex' => 'Male',
			)
			);
		}
	}

	function ept_emp_menu() {
		add_menu_page( "Employee Management System", "ETP EMP", "manage_options", "ETP_EMP_dashboard", array($this, "etp_dashboard"), "dashicons-admin-multisite", 6 );

		add_submenu_page( "ETP_EMP_dashboard", "ETP EMP Dashboard", "Dashboard", "manage_options", "ETP_EMP_dashboard", array($this, "etp_dashboard"), 1 );

		add_submenu_page( "ETP_EMP_dashboard", "All Employees", "All Employees", "manage_options", "ept_all_employee", array($this, "etp_all_employee"), 2 );

		add_submenu_page( "ETP_EMP_dashboard", "Add Employee", "Add Employee", "manage_options", "ept_add_employee", array($this, "etp_add_employee"), 3 );

		add_submenu_page( "ETP_EMP_dashboard", "All Departments", "All Departments", "manage_options", "etp_all_department", array($this, "etp_all_department"), 4 );

		add_submenu_page( "ETP_EMP_dashboard", "Add Department", "Add Department", "manage_options", "etp_add_department", array($this, "etp_add_department"), 5 );

		add_submenu_page( "ETP_EMP_dashboard", "All Departmental Posts", "All Dept. Post", "manage_options", "etp_all_dept_post", array($this, "etp_all_post"), 6 );

		add_submenu_page( "ETP_EMP_dashboard", "Add Departmental Posts", "Add Dept. Posts", "manage_options", "etp_add_dept_post", array($this, "etp_add_post"), 7 );
	}

	public function etp_dashboard()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/dashboard.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}

	public function etp_all_employee()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/all-employee.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}

	public function etp_add_employee()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/employee-creation-form.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}
	public function etp_all_department()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/all-department.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}
	public function etp_add_department()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/dept-creation-form.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}
	public function etp_all_post()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/all-dept-post.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}
	public function etp_add_post()
	{
		ob_start(); //started Buffer
		include_once(EMPEMS_PLUGIN_ABS_PATH."admin/partials/post-creation-form.php");
		$template = ob_get_contents(); //reading content
		ob_end_clean(); //closing and cleaning buffer
		echo $template;
	}

	public function etp_EMS_admin_ajax_request() {
		global $table_prefix, $wpdb;
		$tblname = 'etp_employee';
		$wp_track_table_emp = $table_prefix . $tblname;

		$tblname = 'etp_department';
		$wp_track_table_dept = $table_prefix . $tblname;

		$tblname = 'etp_posts';
		$wp_track_table_post = $table_prefix . $tblname;
		// Make your response and echo it.
		$param = isset($_REQUEST['param'])?$_REQUEST['param']:"";
		if(!empty($param)){
			 if($param == 'create_emp_param'){
				$l_name = $_REQUEST['l_name'];
				$f_name = $_REQUEST['f_name'];
				$email = $_REQUEST['email'];
				$dob = $_REQUEST['dob'];
				$join_date = $_REQUEST['join_date'];
				$mobile = $_REQUEST['mobile'];
				$department = $_REQUEST['department'];
				$post_name = $_REQUEST['post_name'];
				$salary = $_REQUEST['salary'];
				$city = $_REQUEST['city'];
				$country = $_REQUEST['country'];
				$zip = $_REQUEST['zip'];
				$image = $_REQUEST['emp_image_selection'];
				$status = $_REQUEST['status'];
				$created_at = date('Y-m-d H:m:s 0000');
				$current_user = get_current_user_id();
				
				$wpdb->insert($wp_track_table_emp, array(
					'f_name' => $f_name,
					'l_name' => $l_name,
					'email' => $email,
					'dob' => $dob,
					'join_date' =>  $join_date,
					'mobile' => $mobile,
					'd_name' => $department,
					'p_name' => $post_name,
					'salary' =>$salary,
					'city' => $city,
					'country' => $country,
					'zip' => $zip,
					'profile_image' => $image,
					'status' => $status,
					'created_at' => $created_at,
					'createdBy' => $current_user,
				));

					//Response Message sent to jQuery
					if($wpdb->insert_id > 0 ){
						echo json_encode(array(
							'status' => 1,
							'message' => "Employee Created Successfully!",
							
						));
					}else{
						echo json_encode(array(
							'status' => 0,
							'message' => "Fail to Create Employee",
						));
					}

			}else if($param == 'create_dept_param'){
				$d_name = $_REQUEST['d_name'];
				$created_at = date('Y-m-d H:m:s 0000');
				$wpdb->insert($wp_track_table_dept, array(
					'd_name' => $d_name,
					'created_at' =>$created_at,
				));

				//Response Message sent to jQuery
				if($wpdb->insert_id > 0 ){
					echo json_encode(array(
						'status' => 1,
						'message' => "Department Created Successfully!",
						
					));
				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Create Department",
					));
				}
				
			}else if($param == 'create_post_param'){

				$p_name = $_REQUEST['p_name'];
				$created_at = date('Y-m-d H:m:s 0000');
				$wpdb->insert($wp_track_table_post, array(
					'p_name' => $p_name,
					'created_at' => $created_at,
				));

				//Response Message sent to jQuery
				if($wpdb->insert_id > 0 ){
					echo json_encode(array(
						'status' => 1,
						'message' => "Post Created Successfully!",
						
					));
				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Create Post",
					));
				}

			}else if($param == 'delete_row_dept'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				if($row_id > 0 ){
					$wpdb->delete( $wp_track_table_dept, array( 'id' => $row_id ) );
					echo json_encode(array(
						'status' => 1,
						'message' => "Record Deleted Successfully!",
					));
				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Delete Record!",
					));
				}
			}else if($param == 'delete_row_employee'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				//$wpdb->delete( $wp_track_table_emp, array( 'id' => $row_id ) );
				//$wpdb->query("DELETE FROM $wp_track_table_emp WHERE ID = ".$row_id);
				//Response Message sent to jQuery
				if($row_id >0 ){
					$wpdb->delete( $wp_track_table_emp, array( 'id' => $row_id ) );
					echo json_encode(array(
						'status' => 1,
						'message' => "Record Deleted Successfully!",
					));
				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Delete Record!",
					));
				}
			}else if($param == 'edit_row_post'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$redirect = admin_url() . "admin.php";
				if($row_id > 0){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Edit Record!",
						'row_id' => $row_id,
						'url' => $redirect,
					));

				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Edit Record!",
					));
				}
			}else if($param == 'edit_row_dept'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$redirect = admin_url() . "admin.php";
				if($row_id > 0){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Edit Record!",
						'row_id' => $row_id,
						'url' => $redirect,
					));

				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Edit Record!",
					));
				}
			}else if($param == 'edit_row_employee'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$redirect = admin_url() . "admin.php";
				if($row_id > 0){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Edit Record!",
						'row_id' => $row_id,
						'url' => $redirect,
					));

				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Edit Record!",
					));
				}
			}else if($param == 'update_row_dept'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$dept_name = isset($_REQUEST['dept_name'])?$_REQUEST['dept_name']:"";
				$redirect = admin_url() . "admin.php";
				$upadte = $wpdb->update($wp_track_table_dept, 
					array('d_name'=>$dept_name), array('id'=>$row_id));

				if(($row_id > 0) && $upadte){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Update Record!",
						'row_id' => $row_id,
						'dept_name' => $dept_name,
						'url' => $redirect,
					));

				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Update Record!",
					));
				}
			}else if($param == 'update_row_dept_post'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$post_name = isset($_REQUEST['post_name'])?$_REQUEST['post_name']:"";
				$redirect = admin_url() . "admin.php";
				$upadte = $wpdb->update($wp_track_table_post, 
					array('p_name'=>$post_name), array('id'=>$row_id));

				if(($row_id > 0) && $upadte){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Update Record!",
						'row_id' => $row_id,
						'dept_name' => $post_name,
						'url' => $redirect,
					));

				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Update Record!",
					));
				}
			}else if($param == 'update_row_emp'){
				$row_id = isset($_REQUEST['row_id'])?intval($_REQUEST['row_id']):0;
				$redirect = admin_url() . "admin.php";
				$l_name = $_REQUEST['l_name'];
				$f_name = $_REQUEST['f_name'];
				$email = $_REQUEST['email'];
				$dob = $_REQUEST['dob'];
				$join_date = $_REQUEST['join_date'];
				$mobile = $_REQUEST['mobile'];
				$department = $_REQUEST['department'];
				$post_name = $_REQUEST['post_name'];
				$salary = $_REQUEST['salary'];
				$city = $_REQUEST['city'];
				$country = $_REQUEST['country'];
				$zip = $_REQUEST['zip'];
				$image = $_REQUEST['emp_image_selection'];
				$status = $_REQUEST['status'];
				// $created_at = date('Y-m-d H:m:s 0000');
				// $current_user = get_current_user_id();

				$upadte = $wpdb->update($wp_track_table_emp, 
					array(
					'f_name' => $f_name,
					'l_name' => $l_name,
					'email' => $email,
					'dob' => $dob,
					'join_date' =>  $join_date,
					'mobile' => $mobile,
					'd_name' => $department,
					'p_name' => $post_name,
					'salary' =>$salary,
					'city' => $city,
					'country' => $country,
					'zip' => $zip,
					'profile_image' => $image,
					'status' => $status,
					// 'created_at' => $created_at,
					// 'createdBy' => $current_user,
					), array('id'=>$row_id));

				if(($row_id > 0) && $upadte){
					echo json_encode(array(
						'status' => 1,
						'message' => "Success to Update Record!",
						'row_id' => $row_id,
						'url' => $redirect,
					));
				}else{
					echo json_encode(array(
						'status' => 0,
						'message' => "Fail to Update Record!",
					));
				}
			}
		}
		// Don't forget to stop execution afterward.
		wp_die();
	}

}
