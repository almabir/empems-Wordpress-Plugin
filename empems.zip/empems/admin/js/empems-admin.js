(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	//Upload Image From Media Folder in Wordpress
	jQuery(document).on("click", "#ajax_image_emp",  function(){
		var image = wp.media({
			title : "Upload Employee Image",
			multiple : false,
		}).open().on("select", function(e){
			var uploaded_image = image.state().get("selection").first();
			var image_data =uploaded_image.toJSON();
			jQuery("#emp_image_file").attr("src", image_data.url);
			jQuery("#emp_image_selection").val(image_data.url);
			jQuery("#emp_image_file").attr("width", 150);
		});
	});
	

	//Button processing ajax code for deleting Employee
	jQuery(document).on("click", "#emp-delete",function(){
		var $row_id = jQuery(this).attr("data-id");
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'delete_row_employee',
			'row_id' : $row_id,
		};
		var confirmation = confirm("Are you sure to Delete item");
		if(confirmation){
			jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}else{
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}
			});
		}
	});

	//Button processing ajax code for deleting Department
	jQuery(document).on("click", "#delete-etp-dept",function(){
		var $row_id = jQuery(this).attr("data-id");
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'delete_row_dept',
			'row_id' : $row_id,
		};
		var confirmation = confirm("Are you sure to Delete item");
		if(confirmation){
			jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}else{
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}
			});
		}
	});

	//Button processing ajax code for Editing Employee row
	jQuery(document).on("click", "#emp-edit",function(){
		var $row_id = jQuery(this).attr("data-id");
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'edit_row_employee',
			'row_id' : $row_id,
		};

		jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						//alert(data.row_id);
						setTimeout(function(){
							location.href = data.url + "?page=ept_add_employee&emp_id=" + data.row_id;
						}, 100);
					}
			});
	});

	//Button processing ajax code for Editing dept row
	jQuery(document).on("click", "#edit-etp-dept",function(){
		var $row_id = jQuery(this).attr("data-id");
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'edit_row_dept',
			'row_id' : $row_id,
		};

		jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						//alert(data.row_id);
						setTimeout(function(){
							location.href = data.url + "?page=etp_add_department&dept_id=" + data.row_id;
						}, 100);
					}
			});
	});

	//Button processing ajax code for Updating dept row
	jQuery(document).on("click", "#etp-dept-update-form",function(){
		//var $row_id = jQuery(this).attr("data-id");
		var $dept_name = jQuery("[name=d_name]").val();
		var $row_id = jQuery("[name=row_id]").val();
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'update_row_dept',
			'row_id' : $row_id,
			'dept_name' : $dept_name,
		};

		jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.href = data.url + "?page=etp_all_department";
						}, 100);
					}
			});
	});


	//Button processing ajax code for Updating departmental post row
	jQuery(document).on("click", "#etp-post-update-form",function(){
		//var $row_id = jQuery(this).attr("data-id");
		var $post_name = jQuery("[name=p_name]").val();
		var $row_id = jQuery("[name=row_id]").val();
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'update_row_dept_post',
			'row_id' : $row_id,
			'post_name' : $post_name,
		};

		jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.href = data.url + "?page=etp_all_dept_post";
						}, 100);
					}
			});
	});

	//Button processing ajax code for Updating Employee row
	jQuery(document).on("click", "#etp-emp-update-form",function(){
		
		
			$('#etp-emp-update-form').validate({
				submitHandler: function(){
					var $row_id = jQuery("[name=row_id]").val();
					var postdata = jQuery('#etp-emp-update-form').serialize();
					postdata += "&action=ajax_admin_action&param=update_row_emp&row_id=" + $row_id;
					// postdata += {
					// 	'action' : 'ajax_admin_action',
					// 	'param' : 'update_row_emp',
					// 	'row_id' : $row_id,
					// };
					jQuery.post(ajaxurl, postdata, function(response){
						var data = jQuery.parseJSON(response);
						if(data.status == 1){
							alert(data.message);
							setTimeout(function(){
								location.href = data.url + "?page=ept_all_employee";
							}, 100);
						}else{
							alert(data.message);
						}
					});
				}
			});

	});

	//Button processing ajax code for Editing post row
	jQuery(document).on("click", "#edit-etp-post",function(){
		var $row_id = jQuery(this).attr("data-id");
		var postdata = {
			'action' : 'ajax_admin_action',
			'param' : 'edit_row_post',
			'row_id' : $row_id,
		};

		jQuery.post(ajaxurl, postdata, function(response){
				var data = jQuery.parseJSON(response);
					if(data.status == 1){
						//alert(data.row_id);
						setTimeout(function(){
							location.href = data.url + "?page=etp_add_dept_post&post_id=" + data.row_id;
						}, 100);
					}
			});
	});

	//Data Table formation
	$(document).ready( function () {
			$('#emp-datatable').DataTable();
			$('#dept-post').DataTable();
	});

	var ajaxurl = etp_EMS_admin_ajax.ajaxurl;
	//Form Employee Creation Processing ajax code
	$(document).ready(function(){
		$('#etp-emp-submit-form').validate({
			submitHandler: function(){
				var postdata = jQuery('#etp-emp-submit-form').serialize();
				postdata += "&action=ajax_admin_action&param=create_emp_param";
				jQuery.post(ajaxurl, postdata, function(response){
					var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}else{
						alert(data.message);
					}
				});
			}
		});
	});

	//Form Department Creation Processing ajax code
	$(document).ready(function(){
		$('#etp-dept-submit-form').validate({
			submitHandler: function(){
				var postdata = jQuery('#etp-dept-submit-form').serialize();
				postdata += "&action=ajax_admin_action&param=create_dept_param";
				jQuery.post(ajaxurl, postdata, function(response){
					var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}else{
						alert(data.message);
					}
				});
			}
		});
	});

	//Form Posts Creation Processing ajax code
	$(document).ready(function(){
		$('#etp-post-submit-form').validate({
			submitHandler: function(){
				var postdata = jQuery('#etp-post-submit-form').serialize();
				postdata += "&action=ajax_admin_action&param=create_post_param";
				jQuery.post(ajaxurl, postdata, function(response){
					var data = jQuery.parseJSON(response);
					if(data.status == 1){
						alert(data.message);
						setTimeout(function(){
							location.reload();
						}, 100);
					}else{
						alert(data.message);
					}
				});
			}
		});
	});

})( jQuery );
